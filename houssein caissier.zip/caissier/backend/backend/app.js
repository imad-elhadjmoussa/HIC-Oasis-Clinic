// app.js
const express = require('express')
const app = express()
const cors = require('cors')
const ficheRoutes = require('./routes/fiche.routes')
const prestationRoutes = require('./routes/prestation.routes')
const paiementRoutes = require('./routes/paiement.routes')

app.use(cors())
app.use(express.json())

// Routing
console.log('🔹 ficheRoutes:', typeof ficheRoutes);
app.use('/api/fiches', ficheRoutes)
console.log('🔹 prestationRoutes:', typeof prestationRoutes);
app.use('/api/prestations', prestationRoutes)
console.log('🔹 paiementRoutes:', typeof paiementRoutes);
app.use('/api/paiements', paiementRoutes)

const PORT = 3000;
console.log("Initialisation serveur…");
app.listen(PORT, () => console.log(`Serveur lancé sur le port ${PORT}`))

  
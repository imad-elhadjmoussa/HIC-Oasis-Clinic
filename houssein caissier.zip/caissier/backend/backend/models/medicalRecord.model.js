// models/medicalRecord.model.js
const db = require('../db/connection');

const getAllFiches = async () => {
    const [rows] = await db.query('SELECT * FROM MedicalRecord');
    return rows;
};

const getFicheById = async (id) => {
    const [rows] = await db.query('SELECT * FROM MedicalRecord WHERE id = ?', [id]);
    return rows[0];
};

module.exports = {
    getAllFiches,
    getFicheById
};

// models/prestation.model.js
const db = require("../db/connection");

exports.getPrestationsByMedicalRecordId = async (ficheId) => {
  
  const [rows] = await db.query(
  `SELECT 
Prestation.id,
PrestationList.prestation_name,
Prestation.prestation_price AS price,
Prestation.status, 
IFNULL(SUM(Payment.amount_paid), 0) AS amountPaid
FROM Prestation
JOIN PrestationPrice ON Prestation.price_prestation_id = PrestationPrice.id
JOIN PrestationList ON PrestationPrice.prestation_list_id = PrestationList.id
LEFT JOIN Payment ON Payment.prestation_id = Prestation.id
WHERE Prestation.medical_record_id = ?
GROUP BY Prestation.id, PrestationList.prestation_name, Prestation.prestation_price, Prestation.status;`, [ficheId]);

  return rows;
};

exports.getPrestationById = async (id) => {
  const [rows] = await db.query('SELECT * FROM Prestation WHERE id = ?', [id]);
  return rows[0];
};

exports.updateAmountPaid = async (id, amountPaid) => {
  await db.query(`UPDATE Prestation SET amountPaid = ? WHERE id = ?`, [amountPaid, id]);
};

exports.updateStatusAuto = async (id) => {
  try {
    // Obtenir le prix de la prestation
    const [prestationRows] = await db.query(
      `SELECT prestation_price FROM Prestation WHERE id = ?`, 
      [id]
    );
    
    if (prestationRows.length === 0) return null;
    const price = prestationRows[0].prestation_price;
    
    // Calculer le total des paiements
    const [paymentRows] = await db.query(
      `SELECT SUM(amount_paid) AS totalPaid FROM Payment WHERE prestation_id = ?`,
      [id]
    );
    
    const totalPaid = paymentRows[0].totalPaid || 0;
    
    // Pour éviter les problèmes d'arrondi avec les nombres à virgule
    const isPaid = Math.round(totalPaid * 100) >= Math.round(price * 100);
    const newStatus = isPaid ? 'paid' : 'not paid';
    
    // Debug log
    console.log(`Mise à jour status prestation #${id}: Prix=${price}, Payé=${totalPaid}, Statut=${newStatus}`);
    
    // Mettre à jour le statut
    await db.query(`UPDATE Prestation SET status = ? WHERE id = ?`, [newStatus, id]);
    
    return newStatus;
  } catch (error) {
    console.error("Erreur dans updateStatusAuto:", error);
    throw error;
  }
};

exports.updateStatus = async (id, status) => {
  await db.query(`UPDATE Prestation SET status = ? WHERE id = ?`, [status, id]);
};

exports.updatePrice = async (prestationId, nouveauPrix) => {
  // IMPORTANT: on met simplement à jour le prix, sans faire de soustraction incorrecte
  await db.query(
    'UPDATE Prestation SET prestation_price = ? WHERE id = ?',
    [nouveauPrix, prestationId]
  );
  
  // Après mise à jour du prix, mettre à jour le statut automatiquement
  await this.updateStatusAuto(prestationId);
};
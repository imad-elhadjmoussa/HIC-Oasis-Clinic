// fiche.routes.js
const express = require('express');
const ficheController = require('../controllers/ficheNavette.controller');
const router = express.Router();

router.get('/', ficheController.getAll);         // ✅
router.get('/:id', ficheController.getById);     // ✅

module.exports = router;

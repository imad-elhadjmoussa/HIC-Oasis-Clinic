<script setup lang="ts">
import Navbar from './components/Navbar.vue';

</script>

<template>


  <Navbar />

  <div class=" container !my-4 ">
    <Toast />
    <router-view></router-view>
  </div>


</template>



<style scoped>

</style>

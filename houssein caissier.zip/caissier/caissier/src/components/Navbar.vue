<template>
    <header class=" py-2 border-b-[1px] border-gray-200  ">
        <nav class="container">
            <img src="/clinique.jpg" alt="Clinique Logo" class="w-13 h-13 rounded-full" />
        </nav>
    </header>
</template>

<script setup>

</script>
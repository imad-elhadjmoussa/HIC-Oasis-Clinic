import { createRouter, createWebHistory } from 'vue-router';
import Home from '../components/Home.vue';
import PrestationsList from '../components/PrestationsList.vue';

const routes = [
  { path: '/', component: Home },

  // 🔧 ficheId devient un paramètre dynamique avec :
  { 
    path: '/fiches/:ficheId/prestations', 
    component: PrestationsList 
  },


];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;

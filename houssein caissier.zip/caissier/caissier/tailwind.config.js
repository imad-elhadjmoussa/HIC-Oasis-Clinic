/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",          // Si tu as un fichier index.html
    "./src/**/*.{vue,js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

